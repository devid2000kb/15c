MODDIR=${0%/*}
cd $MODDIR

# Boot-loop guard: never start TEE simulation without a keybox.
# On a fresh /data the keybox is restored from init_boot before this runs;
# if it is still missing, skip startup instead of hanging keystore.
i=0
while [ ! -s /data/adb/tricky_store/keybox.xml ] && [ "$i" -lt 30 ]; do
  sleep 1
  i=$((i+1))
done
if [ ! -s /data/adb/tricky_store/keybox.xml ]; then
  echo "$(date) no keybox; TEESimulator not started" >> /data/adb/tricky_store/tee_guard.log 2>/dev/null
  exit 0
fi

# Fork-based supervisor for instant restart
./supervisor ./daemon "$MODDIR" &

# Clear logd size persist properties once boot completes
(
  until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
  done
  setprop persist.logd.size ""
  setprop persist.logd.size.crash ""
  setprop persist.logd.size.system ""
  setprop persist.logd.size.main ""
) &
