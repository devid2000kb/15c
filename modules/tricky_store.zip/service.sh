MODDIR=${0%/*}
cd $MODDIR




i=0
while [ ! -s /data/adb/tricky_store/keybox.xml ] && [ "$i" -lt 30 ]; do
  sleep 1
  i=$((i+1))
done
if [ ! -s /data/adb/tricky_store/keybox.xml ]; then
  echo "$(date) no keybox; TEESimulator not started" >> /data/adb/tricky_store/tee_guard.log 2>/dev/null
  exit 0
fi


./supervisor ./daemon "$MODDIR" &


(
  until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
  done
  setprop persist.logd.size ""
  setprop persist.logd.size.crash ""
  setprop persist.logd.size.system ""
  setprop persist.logd.size.main ""
) &
