# ZZ Auto Sync Test

Temporary module. It does nothing and only proves that WORK -> GitHub -> phone
adds, replaces and removes modules automatically.
