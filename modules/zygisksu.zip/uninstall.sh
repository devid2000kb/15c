#!/system/bin/sh

TMP_PATH=/data/system/neozygisk

rm -rf $TMP_PATH
