#!/system/bin/sh

# A shim: the rules live in the tracer, which a manager cannot call directly because it
# invokes boot stages by file name. One tracer is installed, for the ABI it injects.
# Apply our SELinux rules first: on this ROM Magisk does not apply module
# sepolicy.rule at boot, so the zygisk_file socket would otherwise be unlabeled.
MP=/data/adb/magisk/magiskpolicy
[ -x "$MP" ] || MP=/debug_ramdisk/magiskpolicy
if [ -x "$MP" ]; then
  "$MP" --live --apply "${0%/*}/sepolicy.rule" >/dev/null 2>&1
fi

TRACER=${0%/*}/bin/zygisk-ptrace64
[ -f "$TRACER" ] || TRACER=${0%/*}/bin/zygisk-ptrace32
exec "$TRACER" stage post-fs-data
