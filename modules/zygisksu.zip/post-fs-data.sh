#!/system/bin/sh





MP=/data/adb/magisk/magiskpolicy
[ -x "$MP" ] || MP=/debug_ramdisk/magiskpolicy
if [ -x "$MP" ]; then
  "$MP" --live --apply "${0%/*}/sepolicy.rule" >/dev/null 2>&1
fi

TRACER=${0%/*}/bin/zygisk-ptrace64
[ -f "$TRACER" ] || TRACER=${0%/*}/bin/zygisk-ptrace32
exec "$TRACER" stage post-fs-data
