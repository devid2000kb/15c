#!/system/bin/sh
for M in /data/adb/modules/*; do
  [ -d "$M" ] || continue
  find "$M" -type f -name "*.sh" -exec chmod 755 {} \; 2>/dev/null
  [ -d "$M/bin" ] && find "$M/bin" -type f -exec chmod 755 {} \; 2>/dev/null
done
for X in daemon machikado mazoku; do
  [ -f "/data/adb/modules/tricky_store/$X" ] && chmod 755 "/data/adb/modules/tricky_store/$X" 2>/dev/null
done
exit 0
