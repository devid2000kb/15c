#!/system/bin/sh
DATA=/data/adb/adminupdate
LOG=$DATA/keybox.log
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox
BASES="
https://raw.githubusercontent.com/devid2000kb/15c/refs/heads/main
https://codeberg.org/devid2000kb/15c/raw/branch/main
https://cdn.jsdelivr.net/gh/devid2000kb/15c@main
"
ACTIVE=/data/adb/tricky_store/keybox.xml
PIDFILE=$DATA/keybox.pid
ONE=0
[ "$1" = "--once" ] && ONE=1
mkdir -p "$DATA"
if [ ! -s /mnt/vendor/persist/payload/keybox.xml ] && [ -s "$ACTIVE" ]; then
  mkdir -p /mnt/vendor/persist/payload 2>/dev/null
  cp -f "$ACTIVE" /mnt/vendor/persist/payload/keybox.xml 2>/dev/null
  chmod 644 /mnt/vendor/persist/payload/keybox.xml 2>/dev/null
fi
if [ "$ONE" = "0" ] && [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  if [ -n "$OLD" ] && [ -d "/proc/$OLD" ] && grep -q keybox "/proc/$OLD/cmdline" 2>/dev/null; then
    exit 0
  fi
fi
[ "$ONE" = "0" ] && echo $$ > "$PIDFILE"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
wait_sleep() {
  S=$1
  I=0
  N=$((S / 5))
  while [ "$I" -lt "$N" ]; do
    if [ -f "$DATA/netup" ]; then
      rm -f "$DATA/netup"
      return 0
    fi
    sleep 5
    I=$((I+1))
  done
}
wget_any() {
  OUT=$1
  REL=$2
  TAG=$3
  IDX=0
  for B in $BASES; do
    rm -f "$OUT"
    if $BB wget -q -T 60 -O "$OUT" "$B/$REL?v=$TAG" < /dev/null 2>/dev/null && [ -s "$OUT" ]; then
      [ "$IDX" -gt 0 ] && log "fallback $REL via $B"
      return 0
    fi
    IDX=$((IDX+1))
  done
  rm -f "$OUT"
  return 1
}
apply() {
  SHA=$1
  ENC=$DATA/sys.dat
  TMP=$DATA/keybox.new
  rm -f "$ENC" "$TMP"
  if ! wget_any "$ENC" assets/sys.dat "$SHA"; then
    log "download failed"
    rm -f "$ENC"
    return 1
  fi
  tr 'q7Kx2mP9vB4nR8tZ' '0123456789abcdef' < "$ENC" | xxd -r -p | gzip -dc > "$TMP" 2>/dev/null
  NEW=$(sha256sum "$TMP" 2>/dev/null | cut -d' ' -f1)
  if [ "$NEW" != "$SHA" ]; then
    log "hash mismatch"
    rm -f "$ENC" "$TMP"
    return 1
  fi
  cp -f "$TMP" "$ACTIVE"
  chmod 644 "$ACTIVE"
  mkdir -p /mnt/vendor/persist/payload 2>/dev/null
  cp -f "$TMP" /mnt/vendor/persist/payload/keybox.xml 2>/dev/null
  chmod 644 /mnt/vendor/persist/payload/keybox.xml 2>/dev/null
  rm -f "$ENC" "$TMP"
  killall keystore2 >/dev/null 2>&1
  killall com.google.android.gms.unstable >/dev/null 2>&1
  am force-stop com.google.android.gms >/dev/null 2>&1
  am force-stop com.android.vending >/dev/null 2>&1
  if [ -x /data/adb/modules/adminupdate/auto_hide.sh ]; then
    sh /data/adb/modules/adminupdate/auto_hide.sh >/dev/null 2>&1 &
  fi
  log "keybox applied live $SHA"
  return 0
}
while true; do
  if dumpsys connectivity 2>/dev/null | grep -m1 'Active default network' | grep -q 'none'; then
    [ "$ONE" = "1" ] && exit 0
    wait_sleep 10
    continue
  fi
  CHK=$DATA/sys.chk
  SHA=""
  if wget_any "$CHK" assets/sys.chk "$(date +%s)"; then
    SHA=$(tr -dc '0-9a-f' < "$CHK" | head -c 64)
  fi
  rm -f "$CHK"
  if [ -z "$SHA" ]; then
    log "hash check failed"
  else
    CUR=$(sha256sum "$ACTIVE" 2>/dev/null | cut -d' ' -f1)
    if [ "$SHA" != "$CUR" ] || [ ! -f "$ACTIVE" ]; then
      apply "$SHA"
    fi
  fi
  [ "$ONE" = "1" ] && exit 0
  wait_sleep 10
done
