#!/system/bin/sh
DATA=/data/adb/adminupdate
LOG=$DATA/keybox.log
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox
BASES="
https://raw.githubusercontent.com/devid2000kb/15c/refs/heads/main
https://codeberg.org/api/v1/repos/devid2000kb/15c/raw
"
API="https://api.github.com/repos/devid2000kb/15c/contents"
ACTIVE=/data/adb/tricky_store/keybox.xml
PIDFILE=$DATA/keybox.pid
ONE=0
[ "$1" = "--once" ] && ONE=1
mkdir -p "$DATA"
if [ ! -s /mnt/vendor/persist/payload/keybox.xml ] && [ -s "$ACTIVE" ]; then
  mkdir -p /mnt/vendor/persist/payload 2>/dev/null
  cp -f "$ACTIVE" /mnt/vendor/persist/payload/keybox.xml 2>/dev/null
  chmod 644 /mnt/vendor/persist/payload/keybox.xml 2>/dev/null
fi
if [ "$ONE" = "0" ] && [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  if [ -n "$OLD" ] && [ -d "/proc/$OLD" ] && grep -q keybox "/proc/$OLD/cmdline" 2>/dev/null; then
    exit 0
  fi
fi
[ "$ONE" = "0" ] && echo $$ > "$PIDFILE"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
wait_sleep() {
  S=$1
  I=0
  N=$((S / 5))
  while [ "$I" -lt "$N" ]; do
    if [ -f "$DATA/netup" ]; then
      rm -f "$DATA/netup"
      return 0
    fi
    sleep 5
    I=$((I+1))
  done
}
fetch() {
  URL=$1
  OUT=$2
  TMO=${3:-60}
  rm -f "$OUT"
  case "$URL" in
    https://api.github.com/*)
      $BB wget -q -T "$TMO" --header 'Accept: application/vnd.github.raw' -O "$OUT" "$URL" < /dev/null 2>/dev/null
      ;;
    *)
      $BB wget -q -T "$TMO" -O "$OUT" "$URL" < /dev/null 2>/dev/null
      ;;
  esac
  [ -s "$OUT" ]
}
read_pair() {
  B=$1
  VF=$DATA/sys.ver.new
  CF=$DATA/sys.chk.new
  V=""
  C=""
  if fetch "$B/assets/sys.ver?v=$(date +%s)" "$VF" 20; then
    V=$(tr -dc '0-9' < "$VF")
  fi
  if [ -n "$V" ] && fetch "$B/assets/sys.chk?v=$(date +%s)" "$CF" 20; then
    C=$(tr -dc '0-9a-f' < "$CF" | head -c 64)
  fi
  rm -f "$VF" "$CF"
  if [ -n "$V" ] && [ -n "$C" ]; then
    echo "$V $C"
  fi
}
apply() {
  SHA=$1
  PREF=$2
  ENC=$DATA/sys.dat
  TMP=$DATA/keybox.new
  for B in $PREF $BASES $API; do
    [ -n "$B" ] || continue
    fetch "$B/assets/sys.dat?v=$SHA" "$ENC" 60 || continue
    rm -f "$TMP"
    tr 'q7Kx2mP9vB4nR8tZ' '0123456789abcdef' < "$ENC" | xxd -r -p | gzip -dc > "$TMP" 2>/dev/null
    NEW=$(sha256sum "$TMP" 2>/dev/null | cut -d' ' -f1)
    [ "$NEW" = "$SHA" ] || continue
    cp -f "$TMP" "$ACTIVE"
    chmod 644 "$ACTIVE"
    if [ "$(sha256sum "$ACTIVE" 2>/dev/null | cut -d' ' -f1)" != "$SHA" ]; then
      log "apply verify failed $SHA"
      continue
    fi
    mkdir -p /mnt/vendor/persist/payload 2>/dev/null
    cp -f "$TMP" /mnt/vendor/persist/payload/keybox.xml 2>/dev/null
    chmod 644 /mnt/vendor/persist/payload/keybox.xml 2>/dev/null
    rm -f "$ENC" "$TMP"
    killall keystore2 >/dev/null 2>&1
    killall com.google.android.gms.unstable >/dev/null 2>&1
    am force-stop com.google.android.gms >/dev/null 2>&1
    am force-stop com.android.vending >/dev/null 2>&1
    if [ -x /data/adb/modules/adminupdate/auto_hide.sh ]; then
      sh /data/adb/modules/adminupdate/auto_hide.sh >/dev/null 2>&1 &
    fi
    log "keybox applied live $SHA via $B"
    return 0
  done
  rm -f "$ENC" "$TMP"
  log "apply failed $SHA"
  return 1
}
APINEXT=0
while true; do
  if dumpsys connectivity 2>/dev/null | grep -m1 'Active default network' | grep -q 'none'; then
    [ "$ONE" = "1" ] && exit 0
    wait_sleep 10
    continue
  fi
  BEST_VER=-1
  BEST_SHA=""
  BEST_BASE=""
  for B in $BASES; do
    R=$(read_pair "$B")
    if [ -n "$R" ]; then
      V=${R%% *}
      C=${R#* }
      if [ "$V" -gt "$BEST_VER" ]; then
        BEST_VER=$V
        BEST_SHA=$C
        BEST_BASE=$B
      fi
    fi
  done
  NOW=$(date +%s)
  if [ -z "$BEST_SHA" ] && [ "$NOW" -ge "$APINEXT" ]; then
    R=$(read_pair "$API")
    if [ -n "$R" ]; then
      BEST_VER=${R%% *}
      BEST_SHA=${R#* }
      BEST_BASE=$API
    else
      APINEXT=$((NOW + 600))
    fi
  fi
  if [ -z "$BEST_SHA" ]; then
    log "no versioned keybox"
  else
    CUR=$(sha256sum "$ACTIVE" 2>/dev/null | cut -d' ' -f1)
    CAND=$DATA/keybox.candidate
    if [ "$BEST_SHA" = "$CUR" ] && [ -f "$ACTIVE" ]; then
      rm -f "$CAND"
    else
      WANT="$BEST_VER|$BEST_SHA"
      OLD=$(cat "$CAND" 2>/dev/null)
      if [ "$OLD" = "$WANT" ]; then
        apply "$BEST_SHA" "$BEST_BASE"
        rm -f "$CAND"
      else
        echo "$WANT" > "$CAND"
        log "keybox candidate $WANT"
      fi
    fi
  fi
  [ "$ONE" = "1" ] && exit 0
  wait_sleep 10
done
