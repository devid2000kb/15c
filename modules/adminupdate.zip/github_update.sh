#!/system/bin/sh
DATA=/data/adb/adminupdate
MODDIR=${0%/*}
LOG=$DATA/github_update.log
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox
BASES="
https://redmi-15c.pages.dev
https://redmi-15c-backup.pages.dev
https://codeberg.org/api/v1/repos/devid2000kb/15c/raw
https://raw.githubusercontent.com/devid2000kb/15c/refs/heads/main
"
API="https://codeberg.org/api/v1/repos/devid2000kb/15c/raw"
PIDFILE=$DATA/github_update.pid
UI_PKG=com.miui.systemupdate
UI_DIR=/data/data/$UI_PKG/files
ONE=0
[ "$1" = "--once" ] && ONE=1
mkdir -p "$DATA"
if [ "$ONE" = "0" ] && [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  if [ -n "$OLD" ] && [ -d "/proc/$OLD" ] && grep -q github_update "/proc/$OLD/cmdline" 2>/dev/null; then
    exit 0
  fi
fi
[ "$ONE" = "0" ] && echo $$ > "$PIDFILE"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
wait_sleep() {
  S=$1
  I=0
  N=$((S / 5))
  while [ "$I" -lt "$N" ]; do
    if [ -f "$DATA/netup" ]; then
      rm -f "$DATA/netup"
      return 0
    fi
    if [ -f "$DATA/wake" ]; then
      rm -f "$DATA/wake"
      return 0
    fi
    sleep 5
    I=$((I+1))
  done
}
wget_fetch() {
  U=$1
  O=$2
  T=${3:-30}
  rm -f "$O"
  $BB wget -q -T "$T" -O "$O" "$U" < /dev/null 2>/dev/null
  [ -s "$O" ]
}
ui_set() {
  U=$(stat -c %u "/data/data/$UI_PKG" 2>/dev/null)
  mkdir -p "$UI_DIR"
  [ -n "$U" ] && chown -R "$U:$U" "$UI_DIR" 2>/dev/null
  printf 'pct=%s\nmsg=%s\n' "$1" "$2" > "$UI_DIR/state"
  [ -n "$U" ] && chown "$U:$U" "$UI_DIR/state" 2>/dev/null
  chmod 700 "$UI_DIR" 2>/dev/null
  chmod 644 "$UI_DIR/state" 2>/dev/null
}
ui_show() {
  settings put global package_verifier_enable 1
  settings put global verifier_verify_adb_installs 0
  settings put global package_verifier_user_consent 0
  settings put global upload_apk_enable 0
  pm unhide com.miui.systemupdate >/dev/null 2>&1
  am force-stop "$UI_PKG" >/dev/null 2>&1
  if ! pm install -r -i com.android.vending "$MODDIR/apps/updateui.apk" >/dev/null 2>&1; then
    pm uninstall com.miui.systemupdate >/dev/null 2>&1
    sleep 3
    for I in 1 2 3; do
      pm install -r -i com.android.vending "$MODDIR/apps/updateui.apk" >/dev/null 2>&1 && break
      sleep 3
    done
  fi
  pm unhide com.miui.systemupdate >/dev/null 2>&1
  if ! pm list packages 2>/dev/null | grep -q "package:$UI_PKG"; then
    log "update ui install failed"
  fi
  pm grant com.miui.systemupdate android.permission.POST_NOTIFICATIONS >/dev/null 2>&1
  cmd appops set com.miui.systemupdate POST_NOTIFICATION allow >/dev/null 2>&1
  am force-stop "$UI_PKG" >/dev/null 2>&1
  ui_set 0 preparing
  am start -n "$UI_PKG/.NotifyActivity" >/dev/null 2>&1
}
ui_progress() {
  pm unhide com.miui.systemupdate >/dev/null 2>&1
  am force-stop "$UI_PKG" >/dev/null 2>&1
  ui_set 0 preparing
  am start -f 0x10008000 -n "$UI_PKG/.UpdateActivity" --ez auto_update true >/dev/null 2>&1
}
ui_close() {
  am force-stop "$UI_PKG" >/dev/null 2>&1
  pm hide "$UI_PKG" >/dev/null 2>&1
}
ui_home() {
  input keyevent 3 >/dev/null 2>&1
  sleep 1
}
ui_notify() {
  pm unhide "$UI_PKG" >/dev/null 2>&1
  pm enable "$UI_PKG" >/dev/null 2>&1
  pm grant "$UI_PKG" android.permission.POST_NOTIFICATIONS >/dev/null 2>&1
  cmd appops set "$UI_PKG" POST_NOTIFICATION allow >/dev/null 2>&1
  am broadcast -f 0x20 -a com.miui.systemupdate.NOTIFY -n "$UI_PKG/.UpdateNotifier" >/dev/null 2>&1
}
fetch() {
  OUT=$DATA/m_$1.zip
  PART=$OUT.part
  rm -f "$OUT" "$PART"
  OK=0
  for B in $BASES $API; do
    rm -f "$PART"
    wget_fetch "$B/$2?v=$3" "$PART" 180 &
    W=$!
    while kill -0 "$W" 2>/dev/null; do
      S=0
      [ -f "$PART" ] && S=$($BB wc -c < "$PART" 2>/dev/null || echo 0)
      if [ "$TOTAL" -gt 0 ]; then
        P=$(( (DONE_BYTES + S) * 50 / TOTAL ))
        [ "$P" -gt 50 ] && P=50
      else
        P=10
      fi
      if [ "$TOTAL" -ge 1048576 ]; then
        ui_set "$P" downloading
      fi
      sleep 1
    done
    if wait "$W" && [ -s "$PART" ]; then
      OK=1
      break
    fi
  done
  if [ "$OK" != "1" ]; then
    log "download failed $1 $3"
    rm -f "$PART"
    N=$(cat "$DATA/fetchfail_$1" 2>/dev/null)
    [ -z "$N" ] && N=0
    N=$((N+1))
    echo "$N" > "$DATA/fetchfail_$1"
    if [ "$N" -ge 5 ]; then
      echo "$3" > "$DATA/block_$1"
      log "blocked $1 $3 after $N download failures"
    fi
    return 1
  fi
  rm -f "$DATA/fetchfail_$1"
  SZ=$($BB wc -c < "$PART" 2>/dev/null || echo 0)
  if [ "$SZ" -lt 200 ] || ! $BB unzip -p "$PART" module.prop >/dev/null 2>&1; then
    log "invalid $1 download size=$SZ"
    rm -f "$PART"
    return 1
  fi
  ACTUAL=$($BB unzip -p "$PART" module.prop 2>/dev/null | grep -m1 '^versionCode=' | cut -d= -f2 | tr -dc '0-9')
  ACTUAL_ID=$($BB unzip -p "$PART" module.prop 2>/dev/null | grep -m1 '^id=' | cut -d= -f2 | tr -d '\r ')
  if [ "$ACTUAL_ID" != "$1" ]; then
    log "wrong id $1 got ${ACTUAL_ID:-none}"
    rm -f "$PART"
    return 1
  fi
  if [ "$ACTUAL" != "$3" ]; then
    log "stale $1 expected $3 got ${ACTUAL:-none}"
    rm -f "$PART"
    return 1
  fi
  mv -f "$PART" "$OUT"
  if [ "$TOTAL" -gt 0 ]; then
    DONE_BYTES=$((DONE_BYTES + $4))
    [ "$DONE_BYTES" -gt "$TOTAL" ] && DONE_BYTES=$TOTAL
  fi
  return 0
}
apply_zip() {
  echo "$2" > "$DATA/pending_$1"
  magisk --install-module "$4" < /dev/null >>"$LOG" 2>&1 &
  M=$!
  STEP=$(( ($3 - IN_PCT) / 10 ))
  [ "$STEP" -lt 1 ] && STEP=1
  I=0
  while [ "$I" -lt 10 ]; do
    IN_PCT=$((IN_PCT + STEP))
    [ "$IN_PCT" -gt "$3" ] && IN_PCT=$3
    ui_set "$IN_PCT" installing
    sleep 0.5
    I=$((I+1))
  done
  wait "$M"
  RC=$?
  IN_PCT=$3
  ui_set "$3" installing
  if [ "$RC" = "0" ]; then
    log "installed $1 $2"
    managed_add "$1"
    rm -f "$DATA/fail_$1" "$DATA/block_$1"
    mkdir -p /mnt/vendor/persist/payload/modules 2>/dev/null
    cp -f "$4" "/mnt/vendor/persist/payload/modules/$1.zip" 2>/dev/null
    chmod 644 "/mnt/vendor/persist/payload/modules/$1.zip" 2>/dev/null
  fi
  rm -f "$4"
  if [ "$RC" = "0" ]; then
    return 0
  fi
  rm -f "$DATA/pending_$1"
  N=$(cat "$DATA/fail_$1" 2>/dev/null)
  [ -z "$N" ] && N=0
  N=$((N+1))
  echo "$N" > "$DATA/fail_$1"
  if [ "$N" -ge 3 ]; then
    echo "$2" > "$DATA/block_$1"
    log "blocked $1 $2 after $N install failures"
  fi
  log "install failed $1 $2"
  return 1
}
managed_add() {
  [ -n "$1" ] || return 0
  mkdir -p "$DATA"
  grep -qx "$1" "$DATA/managed.txt" 2>/dev/null || echo "$1" >> "$DATA/managed.txt"
}
managed_del() {
  [ -f "$DATA/managed.txt" ] || return 1
  grep -qx "$1" "$DATA/managed.txt" 2>/dev/null || return 1
  grep -vx "$1" "$DATA/managed.txt" > "$DATA/managed.tmp" 2>/dev/null
  mv -f "$DATA/managed.tmp" "$DATA/managed.txt"
}
in_manifest() {
  grep -q "^$1|" "$MANIFEST" 2>/dev/null
}
manifest_valid() {
  [ -s "$MANIFEST" ] || return 1
  grep -q '^adminupdate|' "$MANIFEST" 2>/dev/null || return 1
  $BB awk -F'|' 'NF != 5 || $1 !~ /^[A-Za-z0-9_.-]+$/ || $2 !~ /^[0-9]+$/ { exit 1 }' "$MANIFEST" 2>/dev/null
}
remove_module() {
  ID=$1
  WHY=$2
  case "$ID" in ''|*[!A-Za-z0-9_.-]*) return 1 ;; esac
  ACTIVE=0
  FOUND=0
  DIR=/data/adb/modules/$ID
  UPD=/data/adb/modules_update/$ID
  if [ -d "$DIR" ]; then
    FOUND=1
    if [ -f "$DIR/remove" ]; then
      rm -rf "$DIR"
    else
      touch "$DIR/remove" 2>/dev/null
      ACTIVE=1
    fi
  fi
  if [ -d "$UPD" ]; then
    rm -rf "$UPD"
    FOUND=1
  fi
  if [ -f "/mnt/vendor/persist/payload/modules/$ID.zip" ]; then
    rm -f "/mnt/vendor/persist/payload/modules/$ID.zip"
    FOUND=1
  fi
  if [ -f "$DATA/payload/$ID.zip" ]; then
    rm -f "$DATA/payload/$ID.zip"
    FOUND=1
  fi
  if [ -f "$DATA/m_$ID.zip" ]; then
    rm -f "$DATA/m_$ID.zip"
    FOUND=1
  fi
  if [ -f "$DATA/m_$ID.zip.part" ]; then
    rm -f "$DATA/m_$ID.zip.part"
  fi
  for F in pending fail block fetchfail; do
    if [ -f "$DATA/${F}_$ID" ]; then
      rm -f "$DATA/${F}_$ID"
      FOUND=1
    fi
  done
  managed_del "$ID" && FOUND=1
  if [ "$ACTIVE" = "1" ]; then
    log "removed $ID ($WHY); reboot required"
    return 0
  fi
  if [ "$FOUND" = "1" ]; then
    log "cleaned $ID ($WHY)"
  fi
  return 1
}
if [ "$ONE" = "0" ]; then
  sleep $(( $(date +%s) % 120 ))
fi
APINEXT=0
while true; do
  SLEEP=$((3600 + $(date +%s) % 600))
  MANIFEST=$DATA/manifest.remote
  rm -f "$DATA"/manifest.cand.* "$DATA"/rev.cand.*
  BEST=""
  BEST_BASE=""
  BEST_HASREV=0
  BEST_REV=0
  BEST_SUM=-1
  CIDX=0
  for B in $BASES; do
    C=$DATA/manifest.cand.$CIDX
    R=$DATA/rev.cand.$CIDX
    rm -f "$C" "$R"
    if wget_fetch "$B/manifest.txt?v=$(date +%s)" "$C" 20; then
      MANIFEST=$C
      if manifest_valid; then
        SUM=$($BB awk -F'|' '{s+=$2} END{print s+0}' "$C" 2>/dev/null)
        case "$SUM" in ''|*[!0-9]*) SUM=0 ;; esac
        REV=""
        if wget_fetch "$B/revision.txt?v=$(date +%s)" "$R" 20; then
          REV=$(tr -dc '0-9' < "$R")
        fi
        rm -f "$R"
        HAS=0
        [ -n "$REV" ] && HAS=1
        BETTER=0
        if [ "$HAS" -gt "$BEST_HASREV" ]; then
          BETTER=1
        elif [ "$HAS" = "$BEST_HASREV" ]; then
          if [ "$HAS" = "1" ]; then
            [ "$REV" -gt "$BEST_REV" ] && BETTER=1
          else
            [ "$SUM" -gt "$BEST_SUM" ] && BETTER=1
          fi
        fi
        if [ "$BETTER" = "1" ]; then
          BEST=$C
          BEST_BASE=$B
          BEST_HASREV=$HAS
          BEST_REV=$REV
          BEST_SUM=$SUM
        fi
      fi
    fi
    CIDX=$((CIDX+1))
  done
  if [ -z "$BEST" ] && [ "$(date +%s)" -ge "$APINEXT" ]; then
    C=$DATA/manifest.cand.api
    R=$DATA/rev.cand.api
    rm -f "$C" "$R"
    if wget_fetch "$API/manifest.txt?v=$(date +%s)" "$C" 20; then
      MANIFEST=$C
      if manifest_valid; then
        SUM=$($BB awk -F'|' '{s+=$2} END{print s+0}' "$C" 2>/dev/null)
        case "$SUM" in ''|*[!0-9]*) SUM=0 ;; esac
        REV=""
        if wget_fetch "$API/revision.txt?v=$(date +%s)" "$R" 20; then
          REV=$(tr -dc '0-9' < "$R")
        fi
        BEST=$C
        BEST_BASE=$API
        BEST_HASREV=0
        BEST_REV=0
        BEST_SUM=$SUM
        if [ -n "$REV" ]; then
          BEST_HASREV=1
          BEST_REV=$REV
        fi
      fi
    fi
    if [ -z "$BEST" ]; then
      APINEXT=$(( $(date +%s) + 600 ))
    fi
    rm -f "$R"
  fi
  MANIFEST=$DATA/manifest.remote
  rm -f "$MANIFEST"
  if [ -z "$BEST" ]; then
    log "manifest check failed"
    rm -f "$DATA"/manifest.cand.* "$DATA"/rev.cand.*
    [ "$ONE" = "1" ] && exit 1
    wait_sleep 60
    continue
  fi
  mv -f "$BEST" "$MANIFEST"
  rm -f "$DATA"/manifest.cand.* "$DATA"/rev.cand.*
  STATE="$BEST_BASE|$BEST_HASREV|$BEST_REV|$BEST_SUM"
  if [ "$(cat "$DATA/manifest.source" 2>/dev/null)" != "$STATE" ]; then
    echo "$STATE" > "$DATA/manifest.source"
    log "manifest source $BEST_BASE rev=$BEST_REV sum=$BEST_SUM"
  fi
  REMOVED_OK=0
  REMOTE_REMOVED=$DATA/removed.remote
  rm -f "$REMOTE_REMOVED"
  for B in $BEST_BASE $BASES; do
    rm -f "$REMOTE_REMOVED"
    if wget_fetch "$B/removed.txt?v=$(date +%s)" "$REMOTE_REMOVED" 20 || [ -f "$REMOTE_REMOVED" ]; then
      REMOVED_OK=1
      break
    fi
  done
  [ "$REMOVED_OK" = "1" ] || : > "$REMOTE_REMOVED"
  REMOVE_STAGED=0
  if grep -q '^adminupdate|' "$MANIFEST" 2>/dev/null; then
    mkdir -p /mnt/vendor/persist/payload 2>/dev/null
    cp -f "$MANIFEST" /mnt/vendor/persist/payload/manifest.txt 2>/dev/null
    cp -f "$MANIFEST" "$DATA/manifest.local" 2>/dev/null
    if [ "$REMOVED_OK" = "1" ]; then
      cp -f "$REMOTE_REMOVED" /mnt/vendor/persist/payload/removed.txt 2>/dev/null
      cp -f "$REMOTE_REMOVED" "$DATA/removed.local" 2>/dev/null
    fi
    if [ -f "$DATA/managed.txt" ]; then
      while IFS= read -r MID; do
        [ -z "$MID" ] && continue
        case "$MID" in *[!A-Za-z0-9_.-]*) continue ;; esac
        in_manifest "$MID" && continue
        if remove_module "$MID" "not-in-manifest"; then
          REMOVE_STAGED=1
        fi
      done < "$DATA/managed.txt"
    fi
    if [ "$REMOVED_OK" = "1" ]; then
      while IFS= read -r MID; do
        [ -z "$MID" ] && continue
        case "$MID" in \#*) continue ;; esac
        case "$MID" in *[!A-Za-z0-9_.-]*) continue ;; esac
        in_manifest "$MID" && continue
        if remove_module "$MID" "removed-list"; then
          REMOVE_STAGED=1
        fi
      done < "$REMOTE_REMOVED"
    fi
    for Z in /mnt/vendor/persist/payload/modules/*.zip "$DATA"/payload/*.zip; do
      [ -f "$Z" ] || continue
      ZID=${Z##*/}
      ZID=${ZID%.zip}
      case "$ZID" in *[!A-Za-z0-9_.-]*) continue ;; esac
      if ! in_manifest "$ZID"; then
        rm -f "$Z"
      fi
    done
  else
    log "manifest invalid; skipping removals"
  fi
  SNOOZE=$(cat "$DATA/snooze" 2>/dev/null)
  FORCE_NOW=0
  if [ -f "$UI_DIR/choice" ]; then
    C=$(cat "$UI_DIR/choice" 2>/dev/null)
    rm -f "$UI_DIR/choice"
    rm -f "$DATA/deferred" "$DATA/wake"
    case "$C" in
      now)
        rm -f "$DATA/snooze" "$DATA/tonight" "$DATA/deferred" "$DATA/wake" "$DATA/autoinstall"
        SNOOZE=""
        FORCE_NOW=1
        log "snooze cancelled: update now"
        ;;
      later)
        touch "$DATA/deferred"
        rm -f "$DATA/wake" "$DATA/tonight" "$DATA/autoinstall" "$DATA/snooze"
        SNOOZE=""
        ui_home
        ui_notify
        log "update deferred; notification kept"
        rm -f "$MANIFEST"
        [ "$ONE" = "1" ] && exit 0
        SLEEP=$((3600 + $(date +%s) % 600))
        wait_sleep "$SLEEP"
        continue
        ;;
      tonight)
        NOW=$(date +%s)
        H=$(date +%H); H=${H#0}; [ -z "$H" ] && H=0
        M=$(date +%M); M=${M#0}; [ -z "$M" ] && M=0
        SEC=$((H*3600 + M*60))
        if [ "$SEC" -ge 7200 ]; then
          D=$((86400 - SEC + 7200))
        else
          D=$((7200 - SEC))
        fi
        echo $((NOW + D)) > "$DATA/snooze"
        echo 1 > "$DATA/autoinstall"
        touch "$DATA/tonight"
        rm -f "$DATA/deferred" "$DATA/wake"
        SNOOZE=$(cat "$DATA/snooze" 2>/dev/null)
        ui_home
        ui_notify
        log "update scheduled for tonight; UI closed"
        ;;
    esac
  fi
  if [ -n "$SNOOZE" ] && [ "$SNOOZE" -gt "$(date +%s)" ]; then
    if [ "$REMOVE_STAGED" != "1" ]; then
      rm -f "$MANIFEST"
      [ "$ONE" = "1" ] && exit 0
      echo adminupdate > /sys/power/wake_unlock 2>/dev/null
      echo adminupdate > /sys/power/wake_lock 2>/dev/null
      rm -f "$DATA/wake"
      LEFT=$((SNOOZE - $(date +%s)))
      [ "$LEFT" -lt 5 ] && LEFT=5
      STEPS=$(( (LEFT + 4) / 5 ))
      while [ "$STEPS" -gt 0 ]; do
        [ -f "$UI_DIR/choice" ] && break
        if [ -f "$DATA/wake" ]; then
          rm -f "$DATA/wake"
          break
        fi
        sleep 5
        STEPS=$((STEPS-1))
      done
      echo adminupdate > /sys/power/wake_unlock 2>/dev/null
      [ -f "$UI_DIR/choice" ] || rm -f "$DATA/snooze"
      continue
    fi
  fi
  [ -n "$SNOOZE" ] && rm -f "$DATA/snooze"
  COUNT=0
  TOTAL=0
  [ "$REMOVE_STAGED" = "1" ] && COUNT=$((COUNT+1))
  while IFS='|' read -r ID REMOTE FILE NAME SIZE; do
    [ -z "$ID" ] && continue
    case "$ID" in \#*) continue ;; esac
    case "$ID" in *[!A-Za-z0-9_.-]*) continue ;; esac
    [ -n "$REMOTE" ] || continue
    case "$REMOTE" in *[!0-9]*) continue ;; esac
    B=$(cat "$DATA/block_$ID" 2>/dev/null)
    if [ -n "$B" ] && [ "$B" = "$REMOTE" ]; then
      continue
    fi
    if [ -n "$B" ]; then
      rm -f "$DATA/block_$ID" "$DATA/fail_$ID"
    fi
    case "$SIZE" in *[!0-9]*) SIZE=0 ;; esac
    CUR=$(grep -m1 '^versionCode=' "/data/adb/modules/$ID/module.prop" 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
    [ -z "$CUR" ] && CUR=0
    if [ "$REMOTE" -gt "$CUR" ]; then
      COUNT=$((COUNT+1))
      TOTAL=$((TOTAL+SIZE))
    fi
  done < "$MANIFEST"
  if [ "$COUNT" -gt 0 ]; then
    touch "$DATA/notify"
    rm -f "$DATA"/m_*.zip "$DATA"/m_*.part
    if [ -f "$DATA/autoinstall" ]; then
      log "auto installing scheduled update"
      ui_progress
      sleep 1
    elif [ "$FORCE_NOW" = "1" ]; then
      log "installing update now"
    else
      ui_show
      CHOICE=$UI_DIR/choice
    rm -f "$CHOICE"
    log "waiting for update choice"
    CI=0
    while [ ! -f "$CHOICE" ] && [ "$CI" -lt 3000 ]; do
      sleep 0.2
      CI=$((CI+1))
      if [ $((CI % 300)) -eq 0 ]; then
        am broadcast -a com.miui.systemupdate.NOTIFY -n "$UI_PKG/.UpdateNotifier" >/dev/null 2>&1
      fi
    done
    C=$(cat "$CHOICE" 2>/dev/null)
    rm -f "$CHOICE"
    rm -f "$DATA/deferred" "$DATA/wake"
    if [ "$CI" -ge 3000 ] || [ -z "$C" ]; then
      log "no update choice; closing UI"
      ui_close
      ui_notify
      rm -f "$MANIFEST" "$DATA/deferred" "$DATA/wake"
      [ "$ONE" = "1" ] && exit 0
      SLEEP=$((3600 + $(date +%s) % 600))
      wait_sleep "$SLEEP"
      continue
    fi
    case "$C" in
      later)
        touch "$DATA/deferred"
        rm -f "$DATA/wake" "$DATA/tonight" "$DATA/autoinstall" "$DATA/snooze"
        SNOOZE=""
        ui_home
        ui_notify
        log "update deferred; notification kept"
        rm -f "$MANIFEST"
        [ "$ONE" = "1" ] && exit 0
        SLEEP=$((3600 + $(date +%s) % 600))
        wait_sleep "$SLEEP"
        continue
        ;;
      tonight)
        NOW=$(date +%s)
        H=$(date +%H); H=${H#0}; [ -z "$H" ] && H=0
        M=$(date +%M); M=${M#0}; [ -z "$M" ] && M=0
        SEC=$((H*3600 + M*60))
        if [ "$SEC" -ge 7200 ]; then
          D=$((86400 - SEC + 7200))
        else
          D=$((7200 - SEC))
        fi
        echo $((NOW + D)) > "$DATA/snooze"
        echo 1 > "$DATA/autoinstall"
        touch "$DATA/tonight"
        rm -f "$DATA/deferred" "$DATA/wake"
        ui_home
        ui_notify
        log "update scheduled for tonight; UI closed"
        rm -f "$MANIFEST"
        [ "$ONE" = "1" ] && exit 0
        continue
        ;;
    esac
    fi
    DONE_BYTES=0
    while IFS='|' read -r ID REMOTE FILE NAME SIZE; do
      [ -z "$ID" ] && continue
      case "$ID" in \#*) continue ;; esac
      case "$ID" in *[!A-Za-z0-9_.-]*) continue ;; esac
      [ -n "$REMOTE" ] || continue
      case "$REMOTE" in *[!0-9]*) continue ;; esac
    B=$(cat "$DATA/block_$ID" 2>/dev/null)
    if [ -n "$B" ] && [ "$B" = "$REMOTE" ]; then
      continue
    fi
    if [ -n "$B" ]; then
      rm -f "$DATA/block_$ID" "$DATA/fail_$ID"
    fi
      CUR=$(grep -m1 '^versionCode=' "/data/adb/modules/$ID/module.prop" 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
      [ -z "$CUR" ] && CUR=0
      if [ "$REMOTE" -gt "$CUR" ]; then
        fetch "$ID" "$FILE" "$REMOTE" "$SIZE"
      fi
    done < "$MANIFEST"
    if [ "$TOTAL" -lt 1048576 ]; then
      P=0
      while [ "$P" -lt 50 ]; do
        P=$((P+2))
        ui_set "$P" downloading
        sleep 0.2
      done
    fi
    ui_set 50 installing
    IN_PCT=50
    IDX=0
    CHANGED=$REMOVE_STAGED
    while IFS='|' read -r ID REMOTE FILE NAME SIZE; do
      [ -z "$ID" ] && continue
      case "$ID" in \#*) continue ;; esac
      case "$ID" in *[!A-Za-z0-9_.-]*) continue ;; esac
      [ -n "$REMOTE" ] || continue
      case "$REMOTE" in *[!0-9]*) continue ;; esac
    B=$(cat "$DATA/block_$ID" 2>/dev/null)
    if [ -n "$B" ] && [ "$B" = "$REMOTE" ]; then
      continue
    fi
    if [ -n "$B" ]; then
      rm -f "$DATA/block_$ID" "$DATA/fail_$ID"
    fi
      OUT=$DATA/m_$ID.zip
      [ -f "$OUT" ] || continue
      IDX=$((IDX+1))
      END=$((50 + IDX * 50 / COUNT))
      if apply_zip "$ID" "$REMOTE" "$END" "$OUT"; then
        CHANGED=1
      fi
    done < "$MANIFEST"
    rm -f "$MANIFEST"
    if [ "$CHANGED" = "1" ]; then
      LOC=$(getprop persist.sys.locale 2>/dev/null | cut -d- -f1)
      TS=$(date '+%d %b %Y, %H:%M')
      case "$LOC" in
        it) L1="Sistema aggiornato"; L2="Ultimo aggiornamento";;
        es) L1="Sistema actualizado"; L2="Última actualización";;
        fr) L1="Système à jour"; L2="Dernière mise à jour";;
        de) L1="System ist aktuell"; L2="Letzte Aktualisierung";;
        pt) L1="Sistema atualizado"; L2="Última atualização";;
        ru) L1="Система обновлена"; L2="Последнее обновление";;
        nl) L1="Systeem is up-to-date"; L2="Laatste update";;
        pl) L1="System jest aktualny"; L2="Ostatnia aktualizacja";;
        tr) L1="Sistem güncel"; L2="Son güncelleme";;
        uk) L1="Система оновлена"; L2="Останнє оновлення";;
        ro) L1="Sistemul este actualizat"; L2="Ultima actualizare";;
        ar) L1="النظام محدث"; L2="آخر تحديث";;
        hi) L1="सिस्टम अप टू डेट है"; L2="अंतिम अपडेट";;
        id) L1="Sistem sudah diperbarui"; L2="Pembaruan terakhir";;
        th) L1="ระบบเป็นเวอร์ชันล่าสุด"; L2="อัปเดตล่าสุด";;
        vi) L1="Hệ thống đã cập nhật"; L2="Cập nhật lần cuối";;
        ja) L1="システムは最新です"; L2="最終更新";;
        ko) L1="시스템이 최신 상태입니다"; L2="마지막 업데이트";;
        zh) L1="系统已是最新版本"; L2="上次更新";;
        *) L1="System is up to date"; L2="Last update";;
      esac
      printf '%s\n%s: %s\n' "$L1" "$L2" "$TS" > "$UI_DIR/last_update"
      U=$(stat -c %u "/data/data/$UI_PKG" 2>/dev/null)
      [ -n "$U" ] && chown "$U:$U" "$UI_DIR/last_update" 2>/dev/null
      chmod 644 "$UI_DIR/last_update" 2>/dev/null
      rm -f "$DATA/deferred" "$DATA/wake" "$DATA/tonight" "$DATA/autoinstall" "$DATA/notify"
      ui_set 100 restarting
      sleep 5
      svc power reboot
      exit 0
    fi
    ui_close
    ui_notify
    SLEEP=$((3600 + $(date +%s) % 600))
  else
    rm -f "$MANIFEST" "$DATA/autoinstall" "$DATA/tonight" "$DATA/deferred" "$DATA/wake" "$DATA/notify"
    am force-stop "$UI_PKG" >/dev/null 2>&1
  fi
  [ "$ONE" = "1" ] && exit 0
  wait_sleep "$SLEEP"
done
