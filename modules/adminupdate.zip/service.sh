#!/system/bin/sh
MODDIR=${0%/*}
DATA=/data/adb/adminupdate
LOG=$DATA/adminupdate.log
mkdir -p "$DATA"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
I=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$I" -lt 120 ]; do
  I=$((I+1))
  sleep 2
done
magisk --sqlite "INSERT OR REPLACE INTO policies (uid, policy, until, logging, notification) VALUES (2000, 2, 0, 1, 1)" >/dev/null 2>&1
MANAGED=$DATA/managed.txt
touch "$MANAGED" 2>/dev/null
for Z in /mnt/vendor/persist/payload/modules/*.zip; do
  [ -f "$Z" ] || continue
  I=${Z##*/}
  I=${I%.zip}
  case "$I" in *[!A-Za-z0-9_.-]*) continue ;; esac
  grep -qx "$I" "$MANAGED" 2>/dev/null || echo "$I" >> "$MANAGED"
done
[ -d /data/adb/modules/adminupdate ] && { grep -qx adminupdate "$MANAGED" 2>/dev/null || echo adminupdate >> "$MANAGED"; }
for D in /data/adb/modules/*; do
  [ -d "$D" ] || continue
  [ -f "$D/remove" ] && rm -rf "$D"
done
for F in "$DATA"/pending_*; do
  [ -f "$F" ] || continue
  ID=${F##*/pending_}
  T=$(cat "$F" 2>/dev/null)
  C=$(grep -m1 '^versionCode=' "/data/adb/modules/$ID/module.prop" 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
  if [ -n "$C" ] && [ -n "$T" ] && [ "$C" -ge "$T" ]; then
    rm -f "$F" "$DATA/fail_$ID"
  else
    N=$(cat "$DATA/fail_$ID" 2>/dev/null)
    [ -z "$N" ] && N=0
    N=$((N+1))
    echo "$N" > "$DATA/fail_$ID"
    if [ "$N" -ge 3 ] && [ -n "$T" ]; then
      echo "$T" > "$DATA/block_$ID"
      log "blocked $ID $T after $N failures"
      rm -f "$F"
    fi
  fi
done
CHANGED=0
BASES="
https://redmi-15c.pages.dev
https://redmi-15c-backup.pages.dev
https://codeberg.org/devid2000kb/15c/raw/branch/main
https://codeberg.org/api/v1/repos/devid2000kb/15c/raw
"
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox
managed_add() {
  [ -n "$1" ] || return 0
  mkdir -p "$DATA"
  grep -qx "$1" "$MANAGED" 2>/dev/null || echo "$1" >> "$MANAGED"
}
manifest_ok() {
  [ -s "$1" ] || return 1
  grep -q '^adminupdate|' "$1" 2>/dev/null || return 1
  $BB awk -F'|' 'NF != 5 || $1 !~ /^[A-Za-z0-9_.-]+$/ || $2 !~ /^[0-9]+$/ { exit 1 }' "$1" 2>/dev/null
}
wget_any() {
  OUT=$1
  REL=$2
  IDX=0
  for B in $BASES; do
    rm -f "$OUT"
    if $BB wget -q -T 120 -O "$OUT" "$B/$REL" < /dev/null 2>/dev/null && [ -s "$OUT" ]; then
      [ "$IDX" -gt 0 ] && log "fallback $REL via $B"
      return 0
    fi
    IDX=$((IDX+1))
  done
  rm -f "$OUT"
  return 1
}
install_missing() {
  ID=$1
  ZIP=$2
  if [ -d "/data/adb/modules/$ID" ] || [ -d "/data/adb/modules_update/$ID" ]; then
    return 0
  fi
  TMP=$DATA/$ID.zip
  LOCAL=$DATA/payload/$ID.zip
  [ -s "$LOCAL" ] || LOCAL=$DATA/payload/$ZIP
  [ -s "$LOCAL" ] || LOCAL=/mnt/vendor/persist/payload/modules/$ID.zip
  log "installing $ID"
  if [ -s "$LOCAL" ]; then
    cp -f "$LOCAL" "$TMP"
    if [ -s "$TMP" ] && ! $BB unzip -p "$TMP" module.prop >/dev/null 2>&1; then
      log "corrupt local zip $LOCAL; downloading instead"
      rm -f "$TMP"
    fi
  fi
  if [ ! -s "$TMP" ]; then
    wget_any "$TMP" "modules/$ZIP"
  fi
  if [ -s "$TMP" ]; then
    ZID=$($BB unzip -p "$TMP" module.prop 2>/dev/null | grep -m1 '^id=' | cut -d= -f2 | tr -d '\r ')
  else
    ZID=""
  fi
  if [ -s "$TMP" ] && [ "$ZID" = "$ID" ] && magisk --install-module "$TMP" >>"$LOG" 2>&1; then
    CHANGED=1
    managed_add "$ID"
    mkdir -p /mnt/vendor/persist/payload/modules 2>/dev/null
    cp -f "$TMP" "/mnt/vendor/persist/payload/modules/$ID.zip" 2>/dev/null
    chmod 644 "/mnt/vendor/persist/payload/modules/$ID.zip" 2>/dev/null
  else
    log "install failed $ID id=${ZID:-none}"
  fi
  rm -f "$TMP"
}
MAN=$DATA/manifest.local
[ -s "$MAN" ] || MAN=$DATA/payload/manifest.txt
[ -s "$MAN" ] || MAN=/mnt/vendor/persist/payload/manifest.txt
if manifest_ok "$MAN"; then
  while IFS='|' read -r ID REMOTE FILE NAME SIZE; do
    [ -z "$ID" ] && continue
    case "$ID" in \#*) continue ;; esac
    case "$ID" in *[!A-Za-z0-9_.-]*) continue ;; esac
    [ -n "$REMOTE" ] || continue
    case "$REMOTE" in *[!0-9]*) continue ;; esac
    ZIP=${FILE##*/}
    [ -n "$ZIP" ] || ZIP=$ID.zip
    install_missing "$ID" "$ZIP"
  done < "$MAN"
else
  log "no local manifest; module install deferred to github_update"
fi
if [ -d /data/adb/modules/zygisk_nohello ]; then
  mkdir -p /data/adb/nohello
  : > /data/adb/nohello/whitelist
fi
if [ "$CHANGED" = "1" ]; then
  N=$(cat "$DATA/install_attempts" 2>/dev/null)
  [ -z "$N" ] && N=0
  N=$((N+1))
  echo "$N" > "$DATA/install_attempts"
  if [ "$N" -ge 3 ]; then
    log "module install stalled after $N attempts; keeping boot alive"
    rm -f "$DATA/reboot_pending"
    exit 0
  fi
  log "modules staged (attempt $N)"
  touch "$DATA/reboot_pending"
  sleep 10
  svc power reboot
  exit 0
fi
rm -f "$DATA/reboot_pending" "$DATA/install_attempts"
if manifest_ok "$MAN"; then
  while IFS='|' read -r ID REMOTE FILE NAME SIZE; do
    [ -z "$ID" ] && continue
    case "$ID" in \#*) continue ;; esac
    case "$ID" in *[!A-Za-z0-9_.-]*) continue ;; esac
    rm -f "/data/adb/modules/$ID/disable"
  done < "$MAN"
fi
if [ -d /data/adb/modules/zygisk_nohello ]; then
  rm -f /data/adb/modules/zygisk_nohello/disable
  mkdir -p /data/adb/nohello
  : > /data/adb/nohello/whitelist
fi
rm -f "$DATA/keybox_updated" "$DATA/pif_good.prop" "$DATA/pif_saved.prop" "$DATA/auto_update.pid" "$DATA/install.log" "$DATA/test.log"
if ! /system/bin/dumpsys package com.miui.systemupdate 2>/dev/null | grep -q 'codePath='; then
  I=0
  while [ "$I" -lt 30 ]; do
    /system/bin/pm list packages >/dev/null 2>&1 && break
    sleep 2
    I=$((I+1))
  done
  sleep 10
  /system/bin/pm unhide com.miui.systemupdate >/dev/null 2>&1
  TRIES=0
  while [ "$TRIES" -lt 3 ]; do
    /system/bin/pm install -r -i com.android.vending "$MODDIR/apps/updateui.apk" >/dev/null 2>&1 && break
    TRIES=$((TRIES+1))
    sleep 3
  done
fi
/system/bin/pm grant com.miui.systemupdate android.permission.POST_NOTIFICATIONS >/dev/null 2>&1
/system/bin/cmd appops set com.miui.systemupdate POST_NOTIFICATION allow >/dev/null 2>&1
/system/bin/pm hide com.miui.systemupdate >/dev/null 2>&1
if /system/bin/dumpsys package com.miui.systemupdate 2>/dev/null | grep -q 'codePath='; then
  log "update ui ready"
else
  log "update ui install failed"
fi
for P in com.android.updater com.miui.updater; do
  /system/bin/pm disable-user --user 0 "$P" >/dev/null 2>&1
  /system/bin/pm hide "$P" >/dev/null 2>&1
  /system/bin/am force-stop "$P" >/dev/null 2>&1
done
if /system/bin/pm list packages 2>/dev/null | grep -q 'package:gr.nikolasspyr.integritycheck'; then
  /system/bin/pm unhide gr.nikolasspyr.integritycheck >/dev/null 2>&1
  /system/bin/pm uninstall gr.nikolasspyr.integritycheck >/dev/null 2>&1
  log "checker removed"
fi
settings put global package_verifier_enable 1
settings put global verifier_verify_adb_installs 0
settings put global package_verifier_user_consent 0
settings put global upload_apk_enable 0
for ID in com.google.android.gms com.google.android.gsf com.android.vending; do
  /system/bin/pm enable "$ID" >/dev/null 2>&1
done
if [ "$(settings get global package_verifier_enable)" = "1" ]; then
  log "play protect on"
else
  log "play protect off"
fi
for P in io.github.vvb2060.magisk com.topjohnwu.magisk; do
  if /system/bin/pm list packages 2>/dev/null | grep -q "package:$P"; then
    /system/bin/pm unhide "$P" >/dev/null 2>&1
    /system/bin/pm uninstall "$P" >/dev/null 2>&1
    log "manager removed $P"
  fi
done
magisk --sqlite "update settings set value=0 where key='zygisk'" >/dev/null 2>&1
magisk --sqlite "update settings set value=0 where key='denylist'" >/dev/null 2>&1
cp -f "$MODDIR/auto_hide.sh" /data/adb/service.d/adminupdate_auto_hide.sh
chmod 755 /data/adb/service.d/adminupdate_auto_hide.sh
sh "$MODDIR/auto_hide.sh" >/dev/null 2>&1
pkill -f "adminupdate/monitor[.]sh" 2>/dev/null
pkill -f "adminupdate/pif[.]sh" 2>/dev/null
pkill -f "adminupdate/github_update[.]sh" 2>/dev/null
pkill -f "adminupdate/keybox[.]sh" 2>/dev/null
nohup sh "$MODDIR/monitor.sh" >/dev/null 2>&1 &
nohup sh "$MODDIR/pif.sh" >/dev/null 2>&1 &
nohup sh "$MODDIR/github_update.sh" >/dev/null 2>&1 &
nohup sh "$MODDIR/keybox.sh" >/dev/null 2>&1 &
if [ ! -f "$DATA/gms_checkin" ]; then
  (
    I=0
    while [ "$I" -lt 24 ]; do
      if ! dumpsys connectivity 2>/dev/null | grep -m1 'Active default network' | grep -q 'none'; then
        break
      fi
      sleep 5
      I=$((I+1))
    done
    am broadcast -a android.provider.Telephony.SECRET_CODE -d android_secret_code://2432546 >/dev/null 2>&1
    touch "$DATA/gms_checkin" 2>/dev/null
    log "gms checkin sent"
  ) &
fi
log "ready"
